<!DOCTYPE html><html ><head>  <script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-TLWR6PJ');</script> <meta charset="UTF-8"><meta http-equiv="X-UA-Compatible" content="IE=edge" /><meta name="viewport" content="width=device-width, initial-scale=1"/><meta name="google-site-verification" content="RgdhAtGWYzGA4q0BCnuITwfnvnVdLWz2ZS1b90rHXtk" /><link rel="icon" href="http://www.foodserviceindia.com/wp-content/themes/vkl/images/favicon.png" type="image/x-icon" /><link rel="profile" href="http://gmpg.org/xfn/11"><link rel="pingback" href="http://www.foodserviceindia.com/xmlrpc.php"><link type="text/css" media="all" href="http://www.foodserviceindia.com/wp-content/cache/autoptimize/css/autoptimize_b07a4bacf91d0397daf8bbcd66699287.css" rel="stylesheet" /><style type="text/css" media="screen">/*FILESTART*/</style><title>Page not found &#8211; Food Service India</title><link rel='dns-prefetch' href='//s0.wp.com' /><link rel='dns-prefetch' href='//secure.gravatar.com' /><link rel='dns-prefetch' href='//fonts.googleapis.com' /><link rel='dns-prefetch' href='//s.w.org' /><link rel="alternate" type="application/rss+xml" title="Food Service India &raquo; Feed" href="http://www.foodserviceindia.com/feed/" /><link rel="alternate" type="application/rss+xml" title="Food Service India &raquo; Comments Feed" href="http://www.foodserviceindia.com/comments/feed/" /> <script type="text/javascript">window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/2.4\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/2.4\/svg\/","svgExt":".svg","source":{"concatemoji":"http:\/\/www.foodserviceindia.com\/wp-includes\/js\/wp-emoji-release.min.js?ver=4.9.6"}};
			!function(a,b,c){function d(a,b){var c=String.fromCharCode;l.clearRect(0,0,k.width,k.height),l.fillText(c.apply(this,a),0,0);var d=k.toDataURL();l.clearRect(0,0,k.width,k.height),l.fillText(c.apply(this,b),0,0);var e=k.toDataURL();return d===e}function e(a){var b;if(!l||!l.fillText)return!1;switch(l.textBaseline="top",l.font="600 32px Arial",a){case"flag":return!(b=d([55356,56826,55356,56819],[55356,56826,8203,55356,56819]))&&(b=d([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]),!b);case"emoji":return b=d([55357,56692,8205,9792,65039],[55357,56692,8203,9792,65039]),!b}return!1}function f(a){var c=b.createElement("script");c.src=a,c.defer=c.type="text/javascript",b.getElementsByTagName("head")[0].appendChild(c)}var g,h,i,j,k=b.createElement("canvas"),l=k.getContext&&k.getContext("2d");for(j=Array("flag","emoji"),c.supports={everything:!0,everythingExceptFlag:!0},i=0;i<j.length;i++)c.supports[j[i]]=e(j[i]),c.supports.everything=c.supports.everything&&c.supports[j[i]],"flag"!==j[i]&&(c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&c.supports[j[i]]);c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&!c.supports.flag,c.DOMReady=!1,c.readyCallback=function(){c.DOMReady=!0},c.supports.everything||(h=function(){c.readyCallback()},b.addEventListener?(b.addEventListener("DOMContentLoaded",h,!1),a.addEventListener("load",h,!1)):(a.attachEvent("onload",h),b.attachEvent("onreadystatechange",function(){"complete"===b.readyState&&c.readyCallback()})),g=c.source||{},g.concatemoji?f(g.concatemoji):g.wpemoji&&g.twemoji&&(f(g.twemoji),f(g.wpemoji)))}(window,document,window._wpemojiSettings);</script> <link rel='stylesheet' id='ot-google-fonts-css'  href='//fonts.googleapis.com/css?family=Open+Sans:300,600,700,800' type='text/css' media='all' /> <script type='text/javascript' src='http://www.foodserviceindia.com/wp-includes/js/jquery/jquery.js?ver=1.12.4'></script> <script type='text/javascript'>var loading_page_settings = {"loadingScreen":"1","backgroundColor":"#fadf09","foregroundColor":"#FFFFFF","backgroundImage":"","additionalSeconds":"0","pageEffect":"none","backgroundRepeat":"repeat","fullscreen":"0","graphic":"bar","text":"1","lp_ls":"0","screen_size":"all","screen_width":"0","deepSearch":"1"};</script> <script type='text/javascript'>var ewd_ufaq_php_data = {"retrieving_results":"Retrieving Results..."};</script> <script type='text/javascript'>var foodiepress = {"ajaxurl":"http:\/\/www.foodserviceindia.com\/wp-admin\/admin-ajax.php","nonce":"209e3b5976","addedtolist":"Added to Fav List!"};</script> <link rel='https://api.w.org/' href='http://www.foodserviceindia.com/wp-json/' /><link rel="EditURI" type="application/rsd+xml" title="RSD" href="http://www.foodserviceindia.com/xmlrpc.php?rsd" /><link rel="wlwmanifest" type="application/wlwmanifest+xml" href="http://www.foodserviceindia.com/wp-includes/wlwmanifest.xml" /><meta name="generator" content="WordPress 4.9.6" />  <script async src="https://www.googletagmanager.com/gtag/js?id=UA-105839856-5"></script> <script>window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', 'UA-105839856-5');</script> <script type="text/javascript">var ajaxurl = 'http://www.foodserviceindia.com/wp-admin/admin-ajax.php';</script> <link rel='dns-prefetch' href='//v0.wordpress.com'/></head><body id="innerpages" class="chefsartpage"><section class="icl-deskmenu"><section id="side-area" class="side-area-widget dfd-background-dark text-left" style="background-color: #ffffff; background-repeat: no-repeat;"><div class="dfd-side-area-mask side-area-controller"></div><div class="widget-vertical-scroll"></div><div class="container_inside clearfix"><div class="menu_inside_wrap floatL"><div class="common_menu_inside"><h4>Products by Brands</h4><div class="menu-brands-container"><ul id="menu-brands" class="menu"><li id="menu-item-2245" class="menu-item menu-item-type-taxonomy menu-item-object-brands menu-item-2245"><a href="http://www.foodserviceindia.com/brands/spring-burst/">Springburst</a></li><li id="menu-item-2246" class="menu-item menu-item-type-taxonomy menu-item-object-brands menu-item-2246"><a href="http://www.foodserviceindia.com/brands/chefs-art/">Chef&#8217;s Art</a></li><li id="menu-item-2247" class="menu-item menu-item-type-taxonomy menu-item-object-brands menu-item-2247"><a href="http://www.foodserviceindia.com/brands/sunbay/">Sunbay</a></li><li id="menu-item-2248" class="menu-item menu-item-type-taxonomy menu-item-object-brands menu-item-2248"><a href="http://www.foodserviceindia.com/brands/marimbula/">MarimBula</a></li><li id="menu-item-2249" class="menu-item menu-item-type-taxonomy menu-item-object-brands menu-item-2249"><a href="http://www.foodserviceindia.com/brands/spicefield/">Spicefield</a></li><li id="menu-item-2977" class="menu-item menu-item-type-taxonomy menu-item-object-brands menu-item-2977"><a href="http://www.foodserviceindia.com/brands/damour/">D&#8217;amour</a></li></ul></div></div><div class="common_menu_inside"><h4>Services</h4><ul><li> <a href="http://www.foodserviceindia.com/services/#in-kitchen-training-and-demonstration">In kitchen training &#038; demo</a></li><li> <a href="http://www.foodserviceindia.com/services/#standardise-recipe">Standardise recipe</a></li><li> <a href="http://www.foodserviceindia.com/services/#build-food-and-beverage-menu">Build Food and Beverage Menu</a></li></ul></div><div class="common_menu_inside"><h4>Recipes</h4><div class="menu-recipes-container"><ul id="menu-recipes" class="menu"><li id="menu-item-2232" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2232"><a href="http://www.foodserviceindia.com/featured-chefs-recipe/">Featured Chef&#8217;s Recipe</a></li><li id="menu-item-2231" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2231"><a href="http://www.foodserviceindia.com/all-recipes/">All Recipes</a></li></ul></div></div></div><div class="menu_inside_wrap floatL"><div class="common_menu_inside"><h4>Products By Solutions</h4><div class="menu-solutions-container"><ul id="menu-solutions" class="menu"><li id="menu-item-2235" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-2235"><a href="http://www.foodserviceindia.com/category/marinades-coatings/">Marinades &#038; Coatings</a></li><li id="menu-item-2236" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-2236"><a href="http://www.foodserviceindia.com/category/taste-enhancers/">Taste Enhancers</a></li><li id="menu-item-2237" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-2237"><a href="http://www.foodserviceindia.com/category/indian-gravies/">Indian Gravies</a></li><li id="menu-item-2238" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-2238"><a href="http://www.foodserviceindia.com/category/beverage/">Beverage</a></li><li id="menu-item-2239" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-has-children menu-item-2239"><a href="http://www.foodserviceindia.com/category/spices/">Spices</a><ul class="sub-menu"><li id="menu-item-2978" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-2978"><a href="http://www.foodserviceindia.com/category/spices/blends/">Blended Spices</a></li></ul></li><li id="menu-item-2240" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-2240"><a href="http://www.foodserviceindia.com/category/sauces/">Sauces</a></li><li id="menu-item-2241" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-2241"><a href="http://www.foodserviceindia.com/category/herbs-sprinklers-dips/">Herbs, Dips &#038; Sprinklers</a></li><li id="menu-item-2242" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-2242"><a href="http://www.foodserviceindia.com/category/soups/">Soups</a></li><li id="menu-item-2243" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-2243"><a href="http://www.foodserviceindia.com/category/pre-mixes/">Pre-Mixes</a></li><li id="menu-item-2244" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-2244"><a href="http://www.foodserviceindia.com/category/bakery-confectionery/">Bakery &#038; Confectionery</a></li></ul></div></div></div><div class="menu_inside_wrap floatL"><div class="common_menu_inside"><h4>About Us</h4><div class="menu-about-us-container"><ul id="menu-about-us" class="menu"><li id="menu-item-2221" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2221"><a href="http://www.foodserviceindia.com/about-us/">Why Food Service India</a></li><li id="menu-item-2222" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2222"><a href="http://www.foodserviceindia.com/testimonials/">Testimonials</a></li><li id="menu-item-2220" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2220"><a href="http://www.foodserviceindia.com/career/">Careers</a></li><li id="menu-item-2223" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2223"><a href="http://www.foodserviceindia.com/faq/">FAQs</a></li></ul></div><ul></ul></div><div class="common_menu_inside"><h4>Latest</h4><div class="menu-latest-container"><ul id="menu-latest" class="menu"><li id="menu-item-2225" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2225"><a href="http://www.foodserviceindia.com/media/">Media</a></li><li id="menu-item-2224" class="menu-item menu-item-type-post_type menu-item-object-page current_page_parent menu-item-2224"><a href="http://www.foodserviceindia.com/blog/">Blog</a></li></ul></div></div><div class="common_menu_inside" style=""> <a class="menunewsletter" data-toggle="modal" data-target="#myModalFooter" style="cursor: pointer;"><h4>SignUp for Newsletter</h4></a></div></div></div><div class="menu_footer_wrap"><div class="menu_footer floatL"> <a href="http://www.foodserviceindia.com/#requestfrm">Request for Samples / Demo</a></div><div class="menu_footer floatL"> <a href="http://www.foodserviceindia.com/contact-us/">Contact Us</a></div><div class="menu_footer floatL"><div class="social_icons"> <a href="https://www.facebook.com/Foodserviceindia/?fref=ts" class="floatL" target="_blank"> <i class="fa fa-facebook-square"></i> </a> <a href="https://twitter.com/Foodserviceind" class="floatL" target="_blank"> <i class="fa fa-twitter-square"></i> </a> <a href="https://www.linkedin.com/company/food-service-india-pvt.-ltd.?trk=biz-companies-cym" class="floatL" target="_blank"> <i class="fa fa-linkedin-square"></i> </a> <a href="https://www.instagram.com/foodserviceindia/?hl=en" class="floatL" target="_blank"> <i class="fa fa-instagram"></i> </a> <a href="https://www.youtube.com/channel/UC-Zp5sU-GJ2ibw90eUj-EwQ" class="floatL" target="_blank"> <i class="fa fa-youtube"></i> </a></div></div></div></section></section><div id="header-container" class="header-style-2"><div id="header"><div class="header-wrap"><div class="header_left"> <a href="http://www.foodserviceindia.com/"> <img src="http://www.foodserviceindia.com/wp-content/themes/vkl/images/logo.png" alt="VKL" class="img-respondnsive" /> </a></div><div class="contactLinkTxt"> <span>For enquiries, please contact <a href="tel:+919744340707">+ 91 9744340707</a> or <a href="http://www.foodserviceindia.com/contact-us/">Try our Samples</a></span></div><section class="icl-deskmenu"><section class="icl-search"><section class="icl-searchInner"><form class="searchbox" method="get" action="http://www.foodserviceindia.com/" role="search"> <input type="search" placeholder="Search......" name="s" class="searchbox-input" onkeyup="buttonUp();" required> <input type="submit" class="searchbox-submit" value=""> <span class="searchbox-icon"><img src="http://www.foodserviceindia.com/wp-content/themes/vkl/images/search-icon.png" alt="search" class="img-respondnsive" /></span></form></section></section><div class="header_right text-center"><div class="header-icons-wrapper"><div class="side-area-controller-wrap"> <a href="#" class="side-area-controller"> <span class="icon-wrap dfd-middle-line"></span> <span class="icon-wrap dfd-top-line"></span> <span class="icon-wrap dfd-bottom-line"></span> </a><span>Menu</span></div></div></div></section><div class="icl-devicemenu960"><div id="mySidenav" class="sidenav"><section class="mobile-menu-inner"><section class="menu_top_wrap"> <a href="javascript:void(0)" class="closebtn" onclick="closeNav()" style="display:block;"><span class="closeicon">&times;</span> <span class="text">Menu</span></a><section class="socialMobileLnk"><section class="icl-socialIcon"> <a href="https://www.facebook.com/Foodserviceindia/?fref=ts" class="floatL" target="_blank"> <i class="fa fa-facebook-square"></i> </a> <a href="https://twitter.com/Foodserviceind" class="floatL" target="_blank"> <i class="fa fa-twitter-square"></i> </a> <a href="https://www.linkedin.com/company/food-service-india-pvt.-ltd.?trk=biz-companies-cym" class="floatL" target="_blank"> <i class="fa fa-linkedin-square"></i> </a> <a href="https://www.instagram.com/foodserviceindia/?hl=en" class="floatL" target="_blank"> <i class="fa fa-instagram"></i> </a> <a href="https://www.youtube.com/channel/UC-Zp5sU-GJ2ibw90eUj-EwQ" class="floatL" target="_blank"> <i class="fa fa-youtube"></i> </a></section></section></section><div class="sidebar"><ul><li> <a href="javascript:void(0)" class="mheading Productscss">Products</a><ul class="sub-menu sub-content"><li> <a href="javascript:void(0)" class="mheading-sub">By Brands</a><ul id="menu-brands-1" class="sub-menu"><li class="menu-item menu-item-type-taxonomy menu-item-object-brands menu-item-2245"><a href="http://www.foodserviceindia.com/brands/spring-burst/">Springburst</a></li><li class="menu-item menu-item-type-taxonomy menu-item-object-brands menu-item-2246"><a href="http://www.foodserviceindia.com/brands/chefs-art/">Chef&#8217;s Art</a></li><li class="menu-item menu-item-type-taxonomy menu-item-object-brands menu-item-2247"><a href="http://www.foodserviceindia.com/brands/sunbay/">Sunbay</a></li><li class="menu-item menu-item-type-taxonomy menu-item-object-brands menu-item-2248"><a href="http://www.foodserviceindia.com/brands/marimbula/">MarimBula</a></li><li class="menu-item menu-item-type-taxonomy menu-item-object-brands menu-item-2249"><a href="http://www.foodserviceindia.com/brands/spicefield/">Spicefield</a></li><li class="menu-item menu-item-type-taxonomy menu-item-object-brands menu-item-2977"><a href="http://www.foodserviceindia.com/brands/damour/">D&#8217;amour</a></li></ul></li><li> <a href="javascript:void(0)" class="mheading-sub">By Solutions</a><ul id="menu-solutions-1" class="sub-menu"><li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-2235"><a href="http://www.foodserviceindia.com/category/marinades-coatings/">Marinades &#038; Coatings</a></li><li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-2236"><a href="http://www.foodserviceindia.com/category/taste-enhancers/">Taste Enhancers</a></li><li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-2237"><a href="http://www.foodserviceindia.com/category/indian-gravies/">Indian Gravies</a></li><li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-2238"><a href="http://www.foodserviceindia.com/category/beverage/">Beverage</a></li><li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-has-children menu-item-2239"><a href="http://www.foodserviceindia.com/category/spices/">Spices</a><ul class="sub-menu"><li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-2978"><a href="http://www.foodserviceindia.com/category/spices/blends/">Blended Spices</a></li></ul></li><li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-2240"><a href="http://www.foodserviceindia.com/category/sauces/">Sauces</a></li><li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-2241"><a href="http://www.foodserviceindia.com/category/herbs-sprinklers-dips/">Herbs, Dips &#038; Sprinklers</a></li><li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-2242"><a href="http://www.foodserviceindia.com/category/soups/">Soups</a></li><li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-2243"><a href="http://www.foodserviceindia.com/category/pre-mixes/">Pre-Mixes</a></li><li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-2244"><a href="http://www.foodserviceindia.com/category/bakery-confectionery/">Bakery &#038; Confectionery</a></li></ul></li></ul></li><li> <a href="javascript:void(0)" class="mheading Services">Services</a><ul class="sub-menu"><li> <a href="http://www.foodserviceindia.com/services/#in-kitchen-training-and-demonstration">In kitchen training &#038; demo</a></li><li> <a href="http://www.foodserviceindia.com/services/#standardise-recipe">Standardise recipe</a></li><li> <a href="http://www.foodserviceindia.com/services/#build-food-and-beverage-menu">Build Food and Beverage Menu</a></li></ul></li><li> <a href="javascript:void(0)" class="mheading Services">Latest</a><ul id="menu-latest-1" class="sub-menu"><li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2225"><a href="http://www.foodserviceindia.com/media/">Media</a></li><li class="menu-item menu-item-type-post_type menu-item-object-page current_page_parent menu-item-2224"><a href="http://www.foodserviceindia.com/blog/">Blog</a></li></ul></li><li> <a href="javascript:void(0)" class="mheading Services">Recipes</a><ul id="menu-recipes-1" class="sub-menu"><li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2232"><a href="http://www.foodserviceindia.com/featured-chefs-recipe/">Featured Chef&#8217;s Recipe</a></li><li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2231"><a href="http://www.foodserviceindia.com/all-recipes/">All Recipes</a></li></ul></li><li> <a href="javascript:void(0)" class="mheading Services">About Us</a><ul id="menu-about-us-1" class="sub-menu"><li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2221"><a href="http://www.foodserviceindia.com/about-us/">Why Food Service India</a></li><li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2222"><a href="http://www.foodserviceindia.com/testimonials/">Testimonials</a></li><li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2220"><a href="http://www.foodserviceindia.com/career/">Careers</a></li><li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2223"><a href="http://www.foodserviceindia.com/faq/">FAQs</a></li></ul></li></ul></div><div class="menu_footer_wrap"><div class="menu_footer floatL"> <a href="http://www.foodserviceindia.com/#requestfrm"><span>Request for <br>Samples / Demo</span></a></div><div class="menu_footer floatL"> <a href="http://www.foodserviceindia.com/contact-us/"><span>Contact Us</span></a></div></div></section></div><section class="icl-search"><section class="icl-searchInner"><form class="searchbox" method="get" action="http://www.foodserviceindia.com/" role="search"> <input type="search" placeholder="Search......" name="s" class="searchbox-input" onkeyup="buttonUp();" required> <input type="submit" class="searchbox-submit" value=""> <span class="searchbox-icon"><img src="http://www.foodserviceindia.com/wp-content/themes/vkl/images/search-icon.png" alt="search" class="img-respondnsive" /></span></form></section></section><div class="header_right text-center"><div class="header-icons-wrapper"><div class="side-area-controller-wrap"> <a href="#" class="side-area-controller-" onclick="openNav()"> <span class="icon-wrap dfd-middle-line"></span> <span class="icon-wrap dfd-top-line"></span> <span class="icon-wrap dfd-bottom-line"></span> </a><span>Menu</span></div></div></div></div></div></div></div><div class="container"><div class="errorpageclass"> <img src="http://www.foodserviceindia.com/wp-content/themes/vkl/images/404.jpg" width="" height="" alt="" /></div></div></div><div class="modal fade" id="myModalFooter" role="dialog"><div class="modal-dialog"><div class="modal-content"><div class="modal-header"> <button type="button" class="close" data-dismiss="modal">&times;</button><h4 class="modal-title">SignUp for our newsletter</h4></div><div class="modal-body formcontainer"><form name="vklNewsletterForm" id="vklNewsletterForm" action="http://www.foodserviceindia.com/signUpNewsletter.php" method="post"> <input type="hidden" name="pagename" id="pagenamefooter" value="" /><div class="row"><div class="col-md-9"><div class="form-group"> <label for="email">Email address:</label> <input type="email" class="form-control" name="newsletetr_email" id="newsletetr_email"></div></div><div class="col-md-3"><div class="form-group buttoncenter"> <input type="submit" id="NewsletterSubmitBtn" value="Sign Up" class="btn btn-default" /></div></div></div></form></div><div class="modal-body thankyoumessage" style="display: none;"><div class="row"><div class="col-md-12"> Thank You for subscribing to our newsletter. We will keep you posted about latest recipes, industry trends, new products and more.</div></div></div></div></div></div><section class="footerSection"><div class="footerCopyRight">&copy; Copyrights 2017 | Food Service (India) Pvt. Ltd | Credits <a href="http://www.pivotroots.com" style="color:#000;" target="_blank" class="">PivotRoots</a></div><div class="footerSocialLink"> <a href="https://www.youtube.com/channel/UC-Zp5sU-GJ2ibw90eUj-EwQ" target="_blank"> <i class="fa fa-youtube"></i> </a> <a href="https://www.facebook.com/Foodserviceindia/?fref=ts" target="_blank"> <i class="fa fa-facebook-square"></i> </a> <a href="https://twitter.com/Foodserviceind" target="_blank"> <i class="fa fa-twitter-square"></i> </a> <a href="https://www.linkedin.com/company/food-service-india-pvt.-ltd.?trk=biz-companies-cym" target="_blank"> <i class="fa fa-linkedin-square"></i> </a> <a href="https://www.instagram.com/foodserviceindia/?hl=en" target="_blank"> <i class="fa fa-instagram"></i> </a> <a href="#footerHidePanel" aria-hidden="true" data-toggle="collapse" data-target="#footerHidePanel" aria-expanded="false" aria-controls="footerHidePanel"> <i class="fa fa-plus plusYellowIcon"></i> </a><div class="newsLetter_footer col-md-6"> <input data-toggle="modal" data-target="#myModalFooter" type="button" value="Sign Up Newsletter"></div></div><div class="clearfix"></div><div class="footerHidePanel collapse" id="footerHidePanel"><p>Some Links Come here</p></div></section><div id="goTop" style="position: fixed; display: block; z-index: 100; bottom: 2%;right: 2%;"> <a id="goTopAnchor" style="opacity: 0.5; cursor: pointer;"> <span id="goTopSpan" class="glyphicon glyphicon-chevron-up" style="font-size: 45px; display: inline-block;"></span> </a></div> <script type="text/javascript">var ajax_file_upload = {
					create_event: function(name, data) {
						if( "object" !== typeof data ) { data = []; }
						var e = document.createEvent('Event');
						e.initEvent(name, true, true);
						e.data = data;
						document.dispatchEvent(e);
					},
					"ajax_path": "http://www.foodserviceindia.com/wp-admin/admin-ajax.php"
				}</script> <div style="display:none"></div> <script type='text/javascript'>var _wpcf7 = {"recaptcha":{"messages":{"empty":"Please verify that you are not a robot."}}};</script> <script type='text/javascript' src='https://s0.wp.com/wp-content/js/devicepx-jetpack.js?ver=202244'></script> <script type='text/javascript'>var uiAutocompleteL10n = {"noResults":"No results found.","oneResult":"1 result found. Use up and down arrow keys to navigate.","manyResults":"%d results found. Use up and down arrow keys to navigate.","itemSelected":"Item selected."};</script> <script type='text/javascript' src='https://secure.gravatar.com/js/gprofiles.js?ver=2022Novaa'></script> <script type='text/javascript'>var WPGroHo = {"my_hash":""};</script> <script type='text/javascript'>var chow = {"logo":"","retinalogo":"","menulabel":"Menu","isotope":"masonry"};</script>  <script>jQuery(document).ready(function() {
                    scroll_events.bind_events( {
                        universal: 1,
                        gtm:0,
                        gst:0,

                        scroll_elements: [],
                        click_elements: [{'select':'#orderFreeSample','category':'Click Tracking','action':'Click','label':'Order Free Samples','bounce':'false','evalue':''}],
                    });
                });</script> <script type='text/javascript' src='https://stats.wp.com/e-202244.js' async='async' defer='defer'></script> <script type='text/javascript'>_stq = window._stq || [];
	_stq.push([ 'view', {v:'ext',j:'1:6.2.1',blog:'127698991',post:'0',tz:'5.5',srv:'www.foodserviceindia.com'} ]);
	_stq.push([ 'clickTrackerInit', '127698991', '0' ]);</script>  <script type="text/javascript">jQuery(window).load(function(){ 
			jQuery('.isotopegrid').masonry({
			  // options
			  itemSelector: '.grid-item',
			  percentPosition: true,
			  gutter: 20,
			});

			jQuery('.isotopegrid1').masonry({
			  // options
			  itemSelector: '.icl-col',
			  percentPosition: true,
			  gutter: 20,
			});
		});
		jQuery(document).ready(function($) {
			$('input[type=radio][name=tellUsWho]').change(function() {
				var selectedOption = $(this).attr('data-link');
				window.location.href = selectedOption;
			});
			$('#buildmenuMob').change(function() {
				var selectedOption = $(this).val();
				window.location.href = selectedOption;
			});
			$('#reviewMenuMob').change(function() {
				var selectedOption = $(this).val();
				window.location.href = selectedOption;
			});
			
			$('input[type=radio][name=reviewMenu]').change(function() {
				var selectedOption = $(this).attr('data-link');
				window.location.href = selectedOption;
			});
			
			$(".owl").owlCarousel({
				slideSpeed : 400,
				singleItem : false,
				pagination : false,
				margin:10,
				items:5,
				nav:true,
				autoplay:true,
				stagePadding:30,
				loop:true,
				navText : ['<img src="http://www.foodserviceindia.com/wp-content/themes/vkl/images/leftArrow.png"/>', '<img src="http://www.foodserviceindia.com/wp-content/themes/vkl/images/rightArow.png" />'],
				responsive:{
					0:{
						items:1,
						stagePadding:30,
						autoplay:true,
						autoplayTimeout:5000,
						autoplayHoverPause:true,
						loop:true,
					},
					599:{
						items:1,
						stagePadding:35,
					},
					640:{
						items:2,
					},
					768:{
						items:2
					},
					960:{
						items:3
					},
					1170:{
						items:5
					}
				}
			});
		});</script> <script>jQuery(window).scroll(function() {
		if (jQuery(this).scrollTop() > 1){ 
			jQuery('#header').addClass("sticky");
			jQuery('#header').css("background","#fff");
			jQuery('.contactLinkTxt').show();
		}
	else{
			jQuery('#header').removeClass("sticky");
			jQuery('#header').css("background","none");
			jQuery('.contactLinkTxt').hide();
		}
	});</script> <script type="text/javascript">jQuery(window).load(function() {
        
      // MASSONRY Without jquery
      var container = document.querySelector('#isotope');
      var msnry = new Masonry( container, {
        itemSelector: '.ms-item',
        columnWidth: '.ms-item',                
      });  
      
        });</script>  <script>function openNav() {
		document.getElementById("mySidenav").style.width = "100%";
	}
	
	function closeNav() {
		document.getElementById("mySidenav").style.width = "0";
	}

	jQuery(document).ready(function() {
		jQuery(".sub-menu.sub-content").hide();		
		jQuery('.sidebar ul li a.mheading.Productscss').click(function(ev) {
			
			jQuery(".sub-menu.sub-content").slideToggle();
		});
		jQuery(".sub-menu").hide()
		jQuery('.sidebar ul li a.mheading.Services').click(function(ev) {
			jQuery(this).next(".sub-menu").slideToggle();
		});
		jQuery('.sidebar ul li a.mheading-sub').click(function(ev) {
			jQuery(".sub-menu.sub-content").show();	
			jQuery(this).next(".sub-menu").slideToggle();
		});
		var searchOpen = false;
		jQuery('.searchbox .img-respondnsive').click(function(){
			if(searchOpen == false){
				jQuery('.contactLinkTxt').css({
					'left':'21%',
					'transition': 'width 0.3s'
				});
				searchOpen = true;
			}
			else{
				jQuery('.contactLinkTxt').css({
					'right':'20%',
					'left':'',
					'transition': 'width 0.3s'
				});
				searchOpen = false;
			}	
		});
		jQuery('#goTop').goTop();


		jQuery('#vklNewsletterForm').validate({ // initialize the plugin
			rules: {
				newsletetr_email: {
					required: true,
					email: true
				}
			},
			errorPlacement: function(error, element) {
				/*if (element.attr("name") == "cinterested_in" ) {
					error.insertAfter(".sp4");
				} else {
					error.insertAfter(element);
				}*/
			},
			submitHandler: function (form) {
				jQuery.ajax({
					type : "post",
					url: "http://www.foodserviceindia.com/signUpNewsletter.php",
					data : {newsletetr_email : jQuery("#newsletetr_email").val()},
					success: function( data ) {
						
						jQuery('#vklNewsletterForm')[0].reset();
						jQuery(".formcontainer").hide();
						jQuery(".thankyoumessage").show();
					}
				});
			}
		});
		function afterSuccess()
		{
			jQuery('#vklNewsletterForm')[0].reset();
			jQuery(".formcontainer").hide();
			jQuery(".thankyoumessage").show();
		}
	});</script> <script type="text/javascript">jQuery('.newsLetter_footer input, .menunewsletter').click(function(){
	jQuery('#myModalFooter').addClass('in');
	jQuery('.modal').css('display','block');
	jQuery(".formcontainer").show();
	jQuery(".thankyoumessage").hide();
});
	jQuery('.close').click(function(){
	jQuery('#myModalFooter').removeClass('in');
	jQuery('.modal').css('display','none');
	jQuery(".formcontainer").hide();
	jQuery(".thankyoumessage").show();
});</script>  <script type="text/javascript" defer src="http://www.foodserviceindia.com/wp-content/cache/autoptimize/js/autoptimize_f7fad5e731b982e7eb7b3d131183ec05.js"></script></body></html>